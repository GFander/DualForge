Convergence-007C-4C-2 selected evidence. Final production b552f2e42407c7da9a113919f8a20a4070f78b0f; compat SHA 1afc82338206901c7057951aa2202c8dadd75cdd95d47fd112bb166d8faa6038.

Authoritative final cohort: cohort-final.json; contract-complete, revision-neo-* (normal control/treatment and separate diagnostic), verified-regression-*, verified-legacy-bridge, supplier-verified, affected-contracts-verified. Original native Forge fixture runs remain valid with unchanged fixture bytes and no compat installed. Initial/superseded attempts, including e6bc... accepting an illegal allocation alias, remain explicitly diagnostic and do not contribute to final PASS.

Selected command/exit/log/assertion/environment/SHA/class evidence and project-owned binaries only. Not an untrimmed copy of every runtime attachment. Worlds, physical server/config copies, third-party libraries and original FnF binary, duplicate classes and intermediate JARs are excluded. Required own before/after classes show exact ABI/business differences. Public copies redact private IPs and email-like tokens; original and archive hashes are separate. Original records are unchanged. Workspace paths are intentional provenance. FnF runtime and client UI NOT RUN.

Verify using python3 verify_archive.py archive.zip --sha256 <external ZIP SHA>. MANIFEST includes every payload member; SHA256SUMS also covers MANIFEST.
