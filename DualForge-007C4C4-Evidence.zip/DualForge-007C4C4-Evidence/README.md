# Original FnF server experiment evidence

Convergence-007C-4C-4; selected raw evidence only, not a full workspace backup.
Base main: 6a9d867edf8751e8ff188dce44e66c1a3bf7ecf8.
Original standard experiments ran with test wrapper commit 0ff21c9; the separate Neo observer C/T ran at 67e3bb7. The observer build input SHA was checked against that committed source.
Production is unchanged 4C-3, commit 9fc9cde97888a2d7894252dc59702d8548d5a5e5.
FnF SHA: bd415b04529c4ffc31e14757488f71dab6917e4560c61e236c3c4d0de6557958.
DualForge SHA: a26893598d1ffdb73078373b007a4d5d54dddd1b774cb2a0fa0dd90fe5602bf7.

Contains commands, exit results, stock JVM command capture, original stdout/stderr/debug logs, registry queries, input identities, original five FnF ClassFiles and javap (ABI evidence), test tool snapshots, own observer/compat artifacts and limited new-world structural-save checks. Original/defined/converted bytecode evidence is distinguished: stock JVM defined bytes are not dumped; offline ClassFiles do not stand in for definition or execution.

The Forge observer and Neo observer pair are separate from the standard runs. Original run directories and failures are retained. No world bytes, full third-party runtime libraries, whole original FnF JAR, credentials or instance/server configuration are included. World structural records contain only fingerprints/limits, not a persistence/restart proof. Food consumption, fuel burning, client UI and persistence functionality remain NOT RUN.

No redaction has been applied to this LOCAL archive; workspace paths remain. This new payload has no authorization for public evidence upload and has NOT been published. The previous C3 authorization is not reused. Public distribution requires a separate payload review/authorization.
