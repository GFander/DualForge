Convergence-007C-4C-1 evidence. Final production commit d850b1c7bf3b16609ed17a58b3fe2eec0c11b751; compat SHA 8fd97a0a4e811aed4e8e084f172341c1b808837e202a22986705e9f0c33360c2.

Raw captures include commands, exits, logs, actual cohort receipts, source/class/JAR identities, verifier before/after and failed attempts. Only verified-* NeoForge runs and supplier-contract-final/affected-contracts-verified count toward final PASS. Initial attempts remain diagnostic records. All three original native Forge runs precede NeoForge. FnF runtime NOT RUN.

Exclusions: worlds, all physical server copies, downloaded third-party libraries, intermediate JARs and duplicate compiled classes. This is a selected minimum evidence export, not every raw runtime byte. The final project JAR and new project-owned fixture JARs plus necessary before/after owned classes are included to verify the actual tested bytes and business preservation.

Publication copies redact detected RFC1918 addresses and unnecessary emails only; originalPath/originalSHA256 and archiveSHA256 distinguish bytes. Original workspace records are not modified. Workspace paths remain intentional provenance. MANIFEST lists every payload member; SHA256SUMS also covers MANIFEST. No private credentials, worlds or downloaded libraries are included.

Verify: python3 verify_archive.py /path/to/archive.zip --sha256 <external ZIP SHA>.
