# FnF actual server behavior evidence (007C-4C-5)

Selected local raw evidence, not a complete workspace backup. Base main dd3d046820589b9c1e4eb46f1a3249efd816fd93; production unchanged 9fc9cde97888a2d7894252dc59702d8548d5a5e5.
FnF SHA bd415b04529c4ffc31e14757488f71dab6917e4560c61e236c3c4d0de6557958; DualForge SHA a26893598d1ffdb73078373b007a4d5d54dddd1b774cb2a0fa0dd90fe5602bf7.

Eight serial fresh-world runs; actual acknowledged official console/tick/slot/lit-state observations, native/Neo food and Tab results, full commands/logs/exit/input SHA, compiled native observers, pinned project compat/coexistence artifacts, actual original five FnF ClassFiles/javap and official host ABI evidence. No worlds, runtime dependencies, full original third-party JAR, server configuration (except explicit test seed initialization), credentials or unrelated cache.

assessment-final.json is the current precise verdict. assessment.json/assess.py/stdout/stderr preserve the initial checker FAIL that wrongly expected a campfire container refusal when Control has no FnF item. Actual Control first refuses exactly Unknown item fnf:bio_fuel. Final assessment checks that exact parser boundary; no server result was rewritten. A separate initial native comparison mixed JSON string slot keys with integer keys; normalized canonical comparison and this limitation are recorded. These are tool issues, not FnF behavior differences.

FNF_SERVER_BOOT/ITEM_REGISTRY/FUEL_FURNACE/TAB_CALLBACK_SERVER/FOOD_PROPERTIES and 4C5_SERVER_BEHAVIOR PASS in the stated scope. Player consumption, client UI and restart/item persistence NOT RUN; no full compatibility claim. Tab observations bound lazy official queries, not uninstrumented total private-lambda counters. Two representative fuels, not every fuel/context, were exercised.

No public upload or public safety review authorized for this new ZIP. Workspace paths retained, no redaction applied. Prior C4 authorization is not reused. Original test worlds and other raw attachments remain in their original task out/ directories.
